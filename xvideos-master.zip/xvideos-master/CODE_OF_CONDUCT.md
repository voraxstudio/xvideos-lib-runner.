# Contributor Covenant Code of Conduct

If it's open source, so it's all bout it's contributors!

I'm no dictator to say what's allowed or not in an open project.
